import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.atomic.AtomicInteger;

public class SpinningBoundedQueue<T> implements SimpleQueue<T> {
    ReentrantLock enqLock, deqLock;
    AtomicInteger size;
    volatile Node head, tail;
    final int capacity;

    public SpinningBoundedQueue(int capacity) {
	this.capacity = capacity;
	this.head = new Node(null);
	this.tail = this.head;
	this.size = new AtomicInteger(0);
	this.enqLock = new ReentrantLock();
	this.deqLock = new ReentrantLock();
    }

    public void enq(T item) {
	Node nd = new Node(item);
	enqLock.lock();
	try {
	    while (size.get() == capacity) { };
	    
	    tail.next = nd;
	    tail = nd;	    
	    
	} finally {
	    
	    enqLock.unlock();
	    
	}
    }

    public T deq() {
	T item;
	deqLock.lock();
	try {

	    while (head.next == null) { };
	    
	    item = head.next.item;
	    head = head.next;

	} finally {
	    deqLock.unlock();
	}

	return item;
    }	

    class Node {
	T item;
	volatile Node next;
	public Node (T item) {
	    this.item = item;
	    next = null;
	}
    }
}
