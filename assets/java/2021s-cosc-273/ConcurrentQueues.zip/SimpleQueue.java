public interface SimpleQueue<T> {
    public T deq() throws EmptyException;
    public void enq(T value);
}
