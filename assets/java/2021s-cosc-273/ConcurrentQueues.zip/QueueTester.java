/*
 * A program to test the performance of SimpleQueue implementations
 */

public class QueueTester {
    public static final int NUM_OPS = 10_000_000;
    public static final int NUM_PROD = 4;
    public static final int NUM_CONS = 4;
    public static final long WAIT = 10;

    public static void main (String[] args) {
	// pick a queue implementation here
	
	SimpleQueue<Integer> queue = new UnboundedQueue<Integer>();
	//SimpleQueue<Integer> queue = new LockFreeQueue<Integer>();
	//SimpleQueue<Integer> queue = new BoundedQueue<Integer>(100);
	//SimpleQueue<Integer> queue = new SpinningBoundedQueue<Integer>(100);	

	Thread[] producers = new Thread[NUM_PROD];
	Thread[] consumers = new Thread[NUM_CONS];

	System.out.println("Performing " + NUM_OPS + " tasks with " + NUM_PROD + " producers and " + NUM_CONS + " consumers.");

	long start = System.currentTimeMillis();

	for (int i = 0; i < NUM_PROD; ++i) {
	    producers[i] = new Thread(new ProducerTask(NUM_OPS / NUM_PROD, queue));
	    producers[i].start();
	}

	for (int i = 0; i < NUM_CONS; ++i) {
	    consumers[i] = new Thread(new ConsumerTask(NUM_OPS / NUM_CONS, queue));
	    consumers[i].start();
	}

	try {
	    for (Thread t : producers) {
		t.join();
	    }

	    for (Thread t : consumers) {
		t.join();
	    }
	} catch (InterruptedException e) {
	    // do nothing
	}

	long stop = System.currentTimeMillis();	    

	System.out.println("That took " + (stop - start) + " ms.");
	
    }
}

class ProducerTask implements Runnable {
    private int nOps;
    private SimpleQueue<Integer> queue;

    public ProducerTask(int nOps, SimpleQueue<Integer> queue) {
	this.nOps = nOps;
	this.queue = queue;
    }

    public void run() {
	for (int i = 0; i < nOps; ++i) {
	    queue.enq(0);


	    long start = System.nanoTime();
	    while (System.nanoTime() - start < QueueTester.WAIT) { };
	}
    }
}


class ConsumerTask implements Runnable {
    private int nOps;
    private SimpleQueue<Integer> queue;

    public ConsumerTask(int nOps, SimpleQueue<Integer> queue) {
	this.nOps = nOps;
	this.queue = queue;
    }

    public void run() {
	for (int i = 0; i < nOps; ++i) {
	    try {
		queue.deq();
		long start = System.nanoTime();
		while (System.nanoTime() - start < QueueTester.WAIT) { };

	    } catch (EmptyException e) {
		--i;
	    }
	}
    }
    
}
