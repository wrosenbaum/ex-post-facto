import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.atomic.AtomicInteger;

public class BoundedQueue<T> implements SimpleQueue<T> {
    ReentrantLock enqLock, deqLock;
    Condition notEmptyCondition, notFullCondition;
    AtomicInteger size;
    volatile Node head, tail;
    final int capacity;

    public BoundedQueue(int capacity) {
	this.capacity = capacity;
	this.head = new Node(null);
	this.tail = this.head;
	this.size = new AtomicInteger(0);
	this.enqLock = new ReentrantLock();
	this.notFullCondition = this.enqLock.newCondition();
	this.deqLock = new ReentrantLock();
	this.notEmptyCondition = this.deqLock.newCondition();
    }

    public void enq(T item) {
	boolean mustWakeDequeuers = false;
	Node nd = new Node(item);
	enqLock.lock();
	try {
	    while (size.get() == capacity) {
		try {
		    // System.out.println("Queue full!");
		    notFullCondition.await();
		} catch (InterruptedException e) {
		    // do nothing
		}
	    }
	    
	    tail.next = nd;
	    tail = nd;
	    
	    if (size.getAndIncrement() == 0) {
		mustWakeDequeuers = true;
	    }
	    
	} finally {
	    
	    enqLock.unlock();
	    
	}

	if (mustWakeDequeuers) {
	    
	    deqLock.lock();
	    
	    try {
		notEmptyCondition.signalAll();
	    } finally {
		deqLock.unlock();
	    }
	}
    }

    public T deq() {
	T item;
	boolean mustWakeEnqueuers = false;
	deqLock.lock();
	try {

	    while (head.next == null) {
		try {
		    // System.out.println("Queue empty!");
		    notEmptyCondition.await();
		} catch(InterruptedException e) {
		    //do nothing
		}
	    }
	    
	    item = head.next.item;
	    head = head.next;

	    if (size.getAndDecrement() == capacity) {
		mustWakeEnqueuers = true;
	    }
	} finally {
	    deqLock.unlock();
	}

	if (mustWakeEnqueuers) {
	    enqLock.lock();
	    try {
		notFullCondition.signalAll();
	    } finally {
		enqLock.unlock();
	    }
	}

	return item;
    }	

    class Node {
	T item;
	volatile Node next;
	public Node (T item) {
	    this.item = item;
	    next = null;
	}
    }
}
