public class FullException extends Exception {
    public FullException() {
	super();
    }
}
