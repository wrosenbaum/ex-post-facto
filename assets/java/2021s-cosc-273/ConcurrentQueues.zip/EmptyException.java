public class EmptyException extends Exception {
    public EmptyException() {
	super();
    }
}
