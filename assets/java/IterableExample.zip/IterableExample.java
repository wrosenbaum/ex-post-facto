import java.util.Random;

public class IterableExample {
    public static void main (String[] args) {
	Random r = new Random();
	IterableList<Animal> zoo = new IterableList<Animal>();
	Animal a;

	// Add some Animals to the zoo
	for (int i = 0; i < 10; i++) {
	    if (r.nextInt() % 2 == 0) {
		a = new Elephant(Names.getRandomName());
	    } else {
		a = new Platypus(Names.getRandomName());
	    }

	    System.out.println("Adding " + a);
	    zoo.add(a);
	}

	// Print the contents of the zoo using a for-each loop
	System.out.println("\nZoo contents:");
	for (Animal animal : zoo) {
	    System.out.println(animal);
	}

	System.out.println("\nFeeding the animals...");

	for (Animal animal : zoo) {
	    animal.feed();
	}
    }
}
