public class GenericList<T> {
    private Node head = null;
    private Node tail = null;


    // add an item to the list
    public void add (T item) {

	Node nd = new Node(item);

	if (tail != null) {
	    
	    tail.next = nd;
	    tail = nd;
	    
	} else {
	    
	    head = nd;
	    tail = nd;
	    
	}
    }
    
    // returns true if item is contained in the list, and
    // false otherwise
    public boolean contains (T item) {
	Node curr = head;

	// iterate over all items in the list, and check if any are
	// equal to item
	while (curr != null) {
	    T currItem = curr.item;
	    if (currItem.equals(item)) {
		return true;
	    }
	    
	    curr = curr.next;
	}
	
	return false;
    }
    
    // remove the first instance of T item from the list
    // has no effect if item is not contained in the list
    public void remove (T item) {
	Node curr = head;

	if (curr == null) {
	    return;
	}

	// check if item stored at head
	if (curr.item.equals(item)) {
	    head = curr.next;

	    return;
	}
	
	Node prev = curr;
	curr = curr.next;

	while (curr != null) {
	    if (curr.item.equals(item)) {
		prev.next = curr.next;

		// check if removing tail
		if (curr.next == null) {
		    tail = prev;
		}
		
		return;
	    }
	    
	    prev = curr;
	    curr = curr.next;
	}
    }

    class Node {
	T item;
	Node next;

	public Node (T item) {
	    this.item = item;
	    next = null;
	}
    }    
}
