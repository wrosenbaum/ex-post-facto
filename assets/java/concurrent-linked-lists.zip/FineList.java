import java.util.concurrent.locks.*;

public class FineList<T> implements SimpleSet<T> {

    private Node head;

    public FineList() {
	head = new Node(Integer.MIN_VALUE);
	head.next = new Node(Integer.MAX_VALUE);
    }

    public boolean add (T item) {
	int key = item.hashCode();
	head.lock();
	Node pred = head;
	try {
	    Node curr = pred.next;
	    curr.lock();
	    try {
		while (curr.key < key) {
		    pred.unlock();
		    pred = curr;
		    curr = curr.next;
		    curr.lock();
		}
		
		if (key == curr.key) {
		    return false;
		}
		
		Node node = new Node(item);
		node.next = curr;
		pred.next = node;
		return true;
	    } finally {
		curr.unlock();
	    }	    
	} finally {
	    pred.unlock();
	}
    }

    public boolean remove (T item) {
	int key = item.hashCode();
	head.lock();
	Node pred = head;
	try {
	    Node curr = pred.next;
	    curr.lock();
	    try {
		while (curr.key < key) {
		    pred.unlock();
		    pred = curr;
		    curr = curr.next;
		    curr.lock();
		}
		
		if (key == curr.key) {
		    pred.next = curr.next;
		    return true;
		}		
		return false;
	    } finally {
		curr.unlock();
	    }	    
	} finally {
	    pred.unlock();
	}
    }
    
    public boolean contains (T item) {
	int key = item.hashCode();
	head.lock();
	Node pred = head;
	try {
	    Node curr = pred.next;
	    curr.lock();
	    try {
		while (curr.key < key) {
		    pred.unlock();
		    pred = curr;
		    curr = curr.next;
		    curr.lock();
		}

		return (key == curr.key);		
	    } finally {
		curr.unlock();
	    }	    
	} finally {
	    pred.unlock();
	}
    }    

    
    private class Node {
	T item;
	int key;
	Node next;
	Lock lock;

	public Node (int key) {
	    this.item = null;
	    this.key = key;
	    this.next = null;
	    this.lock = new ReentrantLock();
	}
	
	public Node (T item) {
	    this.item = item;
	    this.key = item.hashCode();
	    this.next = null;
	    this.lock = new ReentrantLock();
	}

	public void lock () {
	    lock.lock();
	}

	public void unlock () {
	    lock.unlock();
	}
	
    }
}
