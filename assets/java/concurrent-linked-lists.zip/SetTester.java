import java.util.concurrent.ThreadLocalRandom;

public class SetTester {
    // total number of operations to be performed
    public static final int N_OPS = 1_000_000;

    // the number of threads to be used
    public static final int N_THREADS = 8;

    // number of operations per thread
    public static final int OPS_PER_THREAD = N_OPS / N_THREADS;

    // elements in the set are from the range 0...MAX_VALUE - 1
    public static final int[] VALS = {10, 100, 1000, 10_000};
    
    public static void main (String[] args) {
	// choose a concurrent linked list implementation:
	SimpleSet<Integer> set = new CoarseList<Integer>();
	//SimpleSet<Integer> set = new FineList<Integer>();
	//SimpleSet<Integer> set = new OptimisticList<Integer>();
	//SimpleSet<Integer> set = new LazyList<Integer>();
	//SimpleSet<Integer> set = new NonblockingList<Integer>();	

	System.out.println("Performing " + N_OPS + " set operations with " + N_THREADS + " threads...");

	for (int max : VALS) {

	Thread[] threads = new Thread[N_THREADS];

	for (int i = 0; i < N_THREADS; ++i) {
	    threads[i] = new Thread(new SetTask(set, OPS_PER_THREAD, max));
	}
	
	long start = System.currentTimeMillis();

	for (Thread t : threads) {
	    t.start();
	}

	try {
	    for (Thread t : threads) {
		t.join();
	    }
	} catch(InterruptedException e) {
	    // do nothing
	}
	
	long stop = System.currentTimeMillis();

	System.out.println("Max = " + max + ". That took " + (stop - start) +  " ms.");
	}
    }
}

class SetTask implements Runnable {
    final int max;

    enum Op {
	ADD, REMOVE, CONTAINS;

	public static Op getRandomOp() {
	    return values()[ThreadLocalRandom.current().nextInt(values().length)];
	}
    }
    
    SimpleSet<Integer> set;
    int nOps;
    
    public SetTask(SimpleSet<Integer> set, int nOps, int max) {
	this.set = set;
	this.nOps = nOps;
	this.max = max;
    }

    public void run () {
	for (int i = 0; i < nOps; ++i) {	    
	    int val = ThreadLocalRandom.current().nextInt(max);
	    Op op  = Op.getRandomOp(); 

	    switch (op) {
	    case ADD:
		set.add(val);
		break;
	    case REMOVE:
		set.remove(val);
		break;
	    case CONTAINS:
		set.contains(val);
		break;
	    }
	}
    }
}
