import java.util.concurrent.locks.*;

public class OptimisticList<T> implements SimpleSet<T> {

    private Node head;

    public OptimisticList() {
	head = new Node(Integer.MIN_VALUE);
	head.next = new Node(Integer.MAX_VALUE);
    }

    public boolean add (T item) {
	int key = item.hashCode();
	while (true) {
	    Node pred = head;
	    Node curr = pred.next;
	    while (curr.key < key) {
		pred = curr;
		curr = curr.next;
	    }
	    pred.lock();
	    try {
		curr.lock();
		try {
		    if (validate(pred, curr)) {
			if (key == curr.key) {
			    return false;
			}
		
			Node node = new Node(item);
			node.next = curr;
			pred.next = node;
			return true;
		    }
		} finally {
		    curr.unlock();
		}	    
	    } finally {
		pred.unlock();
	    }
	}
    }

    public boolean remove (T item) {
	int key = item.hashCode();
	while (true) {
	    Node pred = head;
	    Node curr = pred.next;
	    while (curr.key < key) {
		pred = curr;
		curr = curr.next;
	    }
	    pred.lock();
	    try {
		curr.lock();
		try {
		    if (validate(pred, curr)) {
			if (key == curr.key) {
			    pred.next = curr.next;
			    return true;
			}

			return false;
		    }
		} finally {
		    curr.unlock();
		}	    
	    } finally {
		pred.unlock();
	    }
	}
    }
    
    public boolean contains (T item) {
	int key = item.hashCode();
	while (true) {
	    Node pred = head;
	    Node curr = pred.next;
	    while (curr.key < key) {
		pred = curr;
		curr = curr.next;
	    }
	    pred.lock();
	    try {
		curr.lock();
		try {
		    if (validate(pred, curr)) {
			return (key == curr.key);
		    }
		} finally {
		    curr.unlock();
		}	    
	    } finally {
		pred.unlock();
	    }
	}
    }

    private boolean validate (Node pred, Node curr) {
	Node node = head;
	while (node.key <= pred.key) {
	    if (node == pred) {
		return pred.next == curr;
	    }

	    node = node.next;
	}

	return false;
    }

    
    private class Node {
	T item;
	int key;
	Node next;
	Lock lock;

	public Node (int key) {
	    this.item = null;
	    this.key = key;
	    this.next = null;
	    this.lock = new ReentrantLock();
	}
	
	public Node (T item) {
	    this.item = item;
	    this.key = item.hashCode();
	    this.next = null;
	    this.lock = new ReentrantLock();
	}

	public void lock () {
	    lock.lock();
	}

	public void unlock () {
	    lock.unlock();
	}
	
    }
}
