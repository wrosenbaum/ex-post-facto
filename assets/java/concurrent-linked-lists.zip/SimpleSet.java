/*
 * Interface SimpleSet<T> stores a set of distinct elements.
 */

public interface SimpleSet<T> {

    /*
     * Add an element to the SimpleSet. Returns true if the element
     * was not already in the set.
     */
    boolean add(T x);

    /*
     * Remove an element from the SimpleSet. Returns true if the
     * element was previously in the set.
     */
    boolean remove(T x);

    /*
     * Test if a given element is contained in the set.
     */
    boolean contains(T x);
}
