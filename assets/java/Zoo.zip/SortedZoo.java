import java.util.Random;

public class SortedZoo {
    public static void main (String[] args) {
	Random r = new Random();
	SortedList<Animal> zoo = new SortedList<Animal>();
	Animal a;

	for (int i = 0; i < 10; i++) {
	    if (r.nextInt() % 2 == 0) {
		a = new Elephant(Names.getRandomName());
	    } else {
		a = new Platypus(Names.getRandomName());
	    }

	    System.out.println("Inserting " + a);
	    zoo.insert(a);
	}

	System.out.println("\nZoo contents:");
	
	while (zoo.hasNext()) {
	    System.out.println(zoo.next());
	}
	
    }
}
