public class Elephant extends Animal {
    private String species;

    public Elephant (String name){
       super(name);
       species = "Elephant";
    }

     @Override
     public String getSpecies(){
	 return species;
     }
      
     @Override
     public String getFavoriteFood(){
	 return "grass";
     }


     @Override
     public void printAnimalFact(){
	 System.out.println("Elephants can recognize themselves in a mirror");
     }

    public void trumpet(){
        System.out.println("Pawoo");
    }
}
