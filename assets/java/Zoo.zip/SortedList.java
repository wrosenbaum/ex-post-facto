public class SortedList<T extends Comparable<T>> {
    private Node head = null;
    private Node tail = null;
    private Node iter = null; // current node for iterating over list

    // add an item to the list
    public void insert (T item) {

	Node nd = new Node(item);

	if (tail == null) {
	    head = nd;
	    tail = nd;
	    iter = nd;
	    return;
	}

	if (item.compareTo(head.item) <= 0) {
	    nd.next = head;
	    head = nd;
	    iter = nd;
	    return;
	}

	Node prev = head;
	Node curr = prev.next;

	while (curr != null && item.compareTo(curr.item) > 0) {
	    prev = curr;
	    curr = curr.next;
	}

	if (curr == null) {
	    prev.next = nd;
	    tail = nd;
	    return;
	}

	prev.next = nd;
	nd.next = curr;
    }
    
    // returns true if item is contained in the list, and
    // false otherwise
    public boolean contains (T item) {
	Node curr = head;

	// iterate over all items in the list, and check if any are
	// equal to item
	while (curr != null) {
	    T currItem = curr.item;
	    if (currItem.equals(item)) {
		return true;
	    }
	    
	    curr = curr.next;
	}
	
	return false;
    }
    
    // remove the first instance of T item from the list
    // has no effect if item is not contained in the list
    public void remove (T item) {
	Node curr = head;

	if (curr == null) {
	    return;
	}

	// check if item stored at head
	if (curr.item.equals(item)) {
	    head = curr.next;

	    // make sure iter refers to new head
	    iter = head;
	    return;
	}
	
	Node prev = curr;
	curr = curr.next;

	while (curr != null) {
	    if (curr.item.equals(item)) {
		prev.next = curr.next;

		// check if removing tail
		if (curr.next == null) {
		    tail = prev;
		}
		
		return;
	    }
	    
	    prev = curr;
	    curr = curr.next;
	}
    }

    // check if a subsequent call to next() will return a non-null value
    // if not, the iterator is reset to head
    public boolean hasNext() {
	if (iter == null) {
	    iter = head;
	    return false;
	}

	return true;
    }

    // return the T stored in the current node, or null if the current
    // node is null
    public T next() {
	if (iter == null) {
	    return null;
	}

	T nextItem = iter.item;
	iter = iter.next;
	return nextItem;
    }

    class Node {
	T item;
	Node next;

	public Node (T item) {
	    this.item = item;
	    next = null;
	}
    }    
}

