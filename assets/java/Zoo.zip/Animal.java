public abstract class Animal implements Comparable<Animal> {
    private String name;

    public Animal (String name) { this.name = name; }

    public String getName () { return name; }

    // returns the Animal's species
    public abstract String getSpecies ();

    // prints a message indicating that the Animal ate some food
    public void feed () {
	System.out.println("You just fed " + name + " the " + getSpecies()
			   + " some " + getFavoriteFood() + "!");
    }

    // returns a String indicating the Animal's favorite food 
    public abstract String getFavoriteFood ();

    public abstract void printAnimalFact ();

    @Override
    public String toString () {
	// print something like "Alice (Elephant)"
	return name + " (" + this.getSpecies() + ")";
    }

    @Override
    public boolean equals (Object obj) {
	if (!(obj instanceof Animal)) {
	    return false;
	}

	Animal a = (Animal) obj;

	if (this.name != a.name) {
    	    return false;
    	}

    	if (this.getSpecies() != a.getSpecies()) {
    	    return false;
    	}

    	return true;

    }

    public int compareTo (Animal a) {
	// compare by species
	//return this.getSpecies().compareTo(a.getSpecies());

	// compare by name
	// return this.name.compareTo(a.name);

	// compare by species first, then name
	if (this.getSpecies().equals(a.getSpecies())) {
	    return this.name.compareTo(a.name);
	}

	return this.getSpecies().compareTo(a.getSpecies());
    }

}
