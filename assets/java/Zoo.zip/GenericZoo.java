public class GenericZoo {
    
    public static void main (String[] args) {
	GenericList<Animal> zoo = new GenericList<Animal>();	

	// add some animals to the Zoo'
	Animal alice = new Platypus("Alice");
	Animal bob = new Elephant("Bob");
	Animal carole = new Platypus("Carole");
	Animal doug = new Elephant("Doug");

	zoo.add(alice);
	zoo.add(bob);
	zoo.add(carole);

	// feed the animals
	while (zoo.hasNext()) {
	    zoo.next().feed();
	}

	// Check if alice is in the zoo
	if (zoo.contains(alice)) {
	    System.out.println(alice + " is in the Zoo!");
	} else {
	    System.out.println(alice + " is not in the Zoo!");	    
	}

	// Check if doug is in the zoo
	if (zoo.contains(doug)) {
	    System.out.println(doug + " is in the Zoo!");
	} else {
	    System.out.println(doug + " is not in the Zoo!");	    
	}

	// Check if bob is in the zoo
	if (zoo.contains(bob)) {
	    System.out.println(bob + " is in the Zoo!");
	} else {
	    System.out.println(bob + " is not in the Zoo!");	    
	}

	// Remove bob from the zoo
	System.out.println("Removing " + bob + " from the zoo...");
	zoo.remove(bob);

	// Check if bob is in the zoo again
	if (zoo.contains(bob)) {
	    System.out.println(bob + " is in the Zoo!");
	} else {
	    System.out.println(bob + " is not in the Zoo!");	    
	}
	
    }
	
}
