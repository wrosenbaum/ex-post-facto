import java.util.Random;

public class Names {

    public static final String[] NAMES = {"Liam", "Olivia", "Noah", "Emma", "Oliver", "Ava", "William", "Sophia", "Elijah", "Isabella", "James", "Charlotte", "Benjamin", "Amelia", "Lucas", "Mia", "Mason", "Harper", "Ethan", "Evelyn"};

    private static Random rand = new Random();

    public static String getRandomName() {
	return NAMES[rand.nextInt(NAMES.length)];
    }
	

	
}
