public class Platypus extends Animal {
    public static String species = "Platypus";
    public static String favoriteFood = "insect larvae";
    public static String animalFact = "A platypus is a mammal that lays eggs and has venomous spikes on its heels!";

    public Platypus (String name) {super(name);}

    public String getSpecies () { return species; }
    public String getFavoriteFood () { return favoriteFood; }

    public void printAnimalFact () {
	System.out.println(animalFact);
    }

    public void sting () {
	System.out.println("Ouch! " + getName() + " just stung you!");
    }
}
