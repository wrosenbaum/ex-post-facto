import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

/*
 * A class representing a bouncing disk object. 
 */

public class BouncingDisk {
    public static final int DEFAULT_RADIUS = 25;
    
    private Pair curPosition;      // position of the center
    private Pair curVelocity;      // disk velocity (px / sec)
    private Pair nextPosition;     // position in next frame
    private Pair nextVelocity;     // velocity in next frame    
    private double radius;
    private Color color;
    private World world;           // the world to which the disk belongs
    
    public BouncingDisk(World world, double radius, Color color, Pair position, Pair velocity) {
	this.world = world;
	this.radius = radius;
	this.color = color;
	curPosition = new Pair(position);
	curVelocity = new Pair(velocity);
	nextPosition = new Pair(position);
	nextVelocity = new Pair(velocity);
    }

    /*
     * Compute the state of the BouncingDisk in the next frame. The
     * parameter 'double time' is the amount of time in seconds
     * elapsed between the current frame and the next frame.
     */
    public void update (double time) {
	Pair delta = curVelocity.times(time);
        nextPosition.set(curPosition.plus(delta));
        bounce();
    }

    /*
     * Advances state to the next frame by setting curPostion and
     * curVelocity to their corresponding next values.
     */
    public void advance () {
	curPosition.set(nextPosition);
	curVelocity.set(nextVelocity);
    }

    // set the current position of the center of the BouncingDisk
    public void setPosition(Pair p){
        curPosition.set(p);
    }

    // set the current velocity of the BouncingDisk
    public void setVelocity(Pair v){
        curVelocity.set(v);
    }

    // draw this BouncingDisk to graphics object g
    public void draw(Graphics g) {
	g.setColor(color);
	g.fillOval( (int) (curPosition.getX() - radius),
		    (int) (curPosition.getY() - radius),
		    (int) (2 * radius), (int) (2 * radius));

    }

    /*
     * Detect a collision with the BouncingDisk and the boundaries of
     * the World, and respond accordingly. For example, when a disk
     * collides with a vertical wall, the horizontal component of its
     * velocity should be negated.
     */
    private void bounce() {
	
        if (nextPosition.getX() - radius <= 0){
            nextVelocity.flipX();
            nextPosition.setX(radius);
        } else if (nextPosition.getX() + radius >= world.getWidth()){
            nextVelocity.flipX();
            nextPosition.setX(world.getWidth() - radius);
        }
	
        if (nextPosition.getY() - radius <= 0){
            nextVelocity.flipY();
            nextPosition.setY(radius);
        } else if (nextPosition.getY() + radius >=  world.getHeight()) {
            nextVelocity.flipY();
            nextPosition.setY(world.getHeight() - radius);
        }
    }
}
