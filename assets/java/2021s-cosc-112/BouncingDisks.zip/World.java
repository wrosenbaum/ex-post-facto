import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

/*
 * A class representing a world of BouncingDisks.
 */

class World {
    /* the default radius of a disk */
    public static final double DEFAULT_RADIUS = 25.0;

    /* the width and height of the world */
    private int width;
    private int height;
    
    /* the number of disks in the world */
    int numDisks;

    /* array of disks in the world */
    BouncingDisk[] disks;

    /*
     * Constructor for the world. Creates a world of a given width,
     * height, and number of disks. Creates new BouncingDisks in
     * random positions and with random velocities.
     */
    public World(int width, int height, int numDisks){
        this.width = width;
        this.height = height;

        this.numDisks = numDisks;
 
        disks  = new BouncingDisk[numDisks];

	Random rand = new Random();
        
        for (int i = 0; i < numDisks; i ++) {
	    double radius = DEFAULT_RADIUS;
	    Color color = new Color(rand.nextFloat(), rand.nextFloat(), rand.nextFloat());

	    /* the minimum max/min coordinates for the center of a
	    Bouncing disk */
	    int xMin = (int) radius;
	    int xMax = (int) (width - radius);
	    int yMin = (int) radius;
	    int yMax = (int) (width - radius);
	    
	    Pair position = new Pair((double) (xMin + rand.nextInt(xMax - xMin)), (double) (yMin + rand.nextInt(yMax - yMin)));
	    Pair velocity = new Pair((double) (rand.nextInt(200) - 100), (double) (rand.nextInt(200) - 100));
	    
	    disks[i] = new BouncingDisk(this, radius, color, position, velocity);
	}
    }

    /* getter methods for width, height, and bouncing disks */
    public int getWidth() { return width; }
    public int getHeight() { return height; }
    public BouncingDisk[] getDisks() { return disks; }

    /* draw all of the disks to a given Graphics object g */
    public void drawDisks(Graphics g){
        for (int i = 0; i < numDisks; i++){
            disks[i].draw(g);
        }
    }

    /* 
     * Update the states of all of the disks in the world. The
     * parameter `time` indicates the elapsed time in seconds between
     * the current frame and the next frame.
     */
    public void update(double time){
        for (int i = 0; i < numDisks; i++) {
	    disks[i].update(time);
	}
	
        for (int i = 0; i < numDisks; i++) {
	    disks[i].advance();
	}
    }	
}
