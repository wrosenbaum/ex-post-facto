/*
 * A class representing a pair of numbers (doubles). You fill out the details!
 */

class Pair {

}
