import java.util.Iterator;

public class QueueList<T> implements SimpleQueue<T>, Iterable<T> {
    private Node head = null;
    private Node tail = null;
    private int size = 0;

    @Override
    public void enq(T item) {	
	Node nd = new Node(item);

	if (head == null) {
	    head = nd;
	    tail = nd;
	    return;
	}
	
	tail.next = nd;
	tail = nd;
	++size;
    }

    @Override
    public T deq() {
	if (head == null) {
	    return null;
	}

	T item = head.item;
	head = head.next;
	--size;
	return item;
    }

    @Override
    public boolean isEmpty() {
	return (head == null);
    }

    public T peek() {
	if (head == null) {
	    return null;
	}

	return head.item;
    }

    public int getSize() {
	return size;
    }

    class Node {
	private Node next;
	private T item;

	public Node(T item) {
	    this.item = item;
	}
    }

    public Iterator<T> iterator() {
	return new ListIterator();
    }
    

    class ListIterator implements Iterator<T> {
	Node curr;
	
	public ListIterator() {
	    curr = head;
	}

	public boolean hasNext() {
	    return (curr != null);
	}

	public T next() {
	    if (curr == null) {
		return null;
	    }
	    
	    T item = curr.item;
	    curr = curr.next;
	    return item;
	}
    }
    
	
}
