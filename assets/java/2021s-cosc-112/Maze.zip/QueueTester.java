public class QueueTester {
    static QueueList<Integer> queue = new QueueList<Integer>();
    
    static void  printQueueContents() {
	System.out.println("queue contents: ");
	for (Integer i : queue) {
	    System.out.println(i);
	}
    }
    
    public static void main(String[] args) {

	System.out.println("queue is empty");

	// enq some values to the queue
	System.out.println("enqueueing 1, 2, and 3...");
	
	queue.enq(1);
	queue.enq(2);
	queue.enq(3);
	printQueueContents();

	// print the top value
	System.out.println("the value of the head is " + queue.peek());

	// deq the top value    
	int val = queue.deq();
	System.out.println("dequeued " + val + " from the queue");
	printQueueContents();

	// enq another value
	val = 4;
	System.out.println("enqueueing " + val);
	queue.enq(val);
	printQueueContents();

	// remove everything from the stack
	System.out.println("removing everything from the queue...");
	
	while (!queue.isEmpty()) {
	    System.out.println("dequeued " + queue.deq());
	}
	
    }
}
