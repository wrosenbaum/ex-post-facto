import java.util.ArrayList;

public class Maze {
    private Cell[][] cells;

    // vertWalls[row][col] true if wall separating cell[i][j] from cell[i][j+1] 
    private boolean[][] vertWalls;

    // horWalls[row][col] true if wall separating cell[i][j] from cell[i+1][j]
    private boolean[][] horWalls;
    
    private Cell start;
    private Cell goal;

    // constructor for Maze
    //   - source is in row sRow and column sCol
    //   - goal is in row gRow and column gCol
    public Maze (int width, int height, int sRow, int sCol, int gRow, int gCol, boolean[][] vertWalls, boolean[][] horWalls) {
	this.vertWalls = vertWalls;
	this.horWalls = horWalls;
	
	cells = new Cell[height][width];
	
	for (int i = 0; i < height; i++) {
	    for (int j = 0; j < width; j++) {
		cells[i][j] = new Cell(this, i, j, (i == gRow && j == gCol));
	    }

	}

	setNeighbors();

	start = cells[sRow][sCol];
	goal = cells[gRow][gCol];
    }

    // assign neighbors to Cells in cells according to grid and walls
    private void setNeighbors () {
	for (int i = 0; i < cells.length; i++) {
	    for (int j = 0; j < cells[i].length; j++) {

		//System.out.println("Adding neighbors for cell (" + i + ", " + j + ")");

		// add north neighbor, if any
		if (i > 0 && !horWalls[i-1][j])
		    cells[i][j].addNeighbor(cells[i-1][j]);

		// add east neighbor, if any
		if (j < cells[i].length - 1 && !vertWalls[i][j])
		    cells[i][j].addNeighbor(cells[i][j+1]);

		// add south neighbor, if any
		if (i < cells.length - 1 && !horWalls[i][j])
		    cells[i][j].addNeighbor(cells[i+1][j]);

		// add west neighbor, if any
		if (j > 0 && !vertWalls[i][j-1]) {
		    cells[i][j].addNeighbor(cells[i][j-1]);
		}			
	    }
	}
    }

    // return a string that either prints path from start to goal, or
    // a message indicating that no such solution exists
    public String getDepthFirstSolution () {
	StackList<Cell> active = new StackList<Cell>();
	active.push(start);

	ArrayList<Cell> visited = new ArrayList<Cell>();
	
	if (solveDepthFirst(active, visited)) {
	    StringBuilder str = new StringBuilder();
	    
	    while (!active.isEmpty()) {
		str.insert(0, active.pop().toString() + ", ");
	    }

	    return str.toString();
	}

	return "Maze not solvable.";
    }

    // use depth-first strategy to solve
    private boolean solveDepthFirst (StackList<Cell> active, ArrayList<Cell> visited) {
	// first check if current (i.e., top of active) is goal
	// if so, return true
	if (active.peek().isGoal())
	    return true;

	// the "current" Cell cur is the top Cell in active
	Cell cur = active.peek();
	ArrayList<Cell> neighbors = cur.getNeighbors();

	// check if maze can be solved from any of cur's neighbors
	for (Cell cell : neighbors) {
	    if (!visited.contains(cell)) {
		visited.add(cell);
		active.push(cell);

		// if we reached goal from cell, return true!
		// in this case, active contains all cells along path from start to goal
		if (solveDepthFirst(active, visited))
		    return true;
	    }
	}

	// if no solution found from cur, pop cur off stack and return false
	active.pop();
	return false;
    }

    // return solution found by breadth first search represented as a
    // String
    public String getBreadthFirstSolution () {
	Cell next = solveBreadthFirst();

	if (next == null)
	    return "Maze not solvable";


	StringBuilder str = new StringBuilder();
	    
	while (next != null) {
	    str.insert(0, next.toString() + ", ");
	    next = next.getParent();
	}

	return str.toString();
    }
    
    // Find a solution to the maze using breadth first search. Returns the goal cell. A path from goal to start can be found by following each Cell's parent. If the goal isn't found, null is returned.
    public Cell solveBreadthFirst () {
	// all visited cells
	ArrayList<Cell> visited = new ArrayList<Cell>();
	
	// active Cells are those that have been added to visited, but
	// not processed yet
	QueueList<Cell> active = new QueueList<Cell>();

	// next is the next cell to be processed
	Cell next = start;

	visited.add(next);

	// continue searching until goal is found or all reachable
	// Cells have been visited
	while (!next.isGoal()) {
	    for (Cell c : next.getNeighbors()) {
		if (!visited.contains(c)) {
		    visited.add(c);
		    active.enq(c);
		    c.setParent(next);
		}
	    }

	    if (!active.isEmpty()) 
		next = active.deq();
	    else
		// visited all cells without finding the goal
		return null; 
	}

	return next;
    }

    // return a string representation of the maze
    public String toString () {
	StringBuilder str = new StringBuilder();

	// draw top edge
	for (int j = 0; j < horWalls[0].length; j++) {
	    str.append("+-");
	}
	str.append("+\n");

	for (int i = 0; i < vertWalls.length; i++) {

	    // draw vertical walls
	    str.append("|");
	    for (int j = 0; j < vertWalls[i].length; j++) {
		str.append(" ");
		if (vertWalls[i][j])
		    str.append("|");
		else
		    str.append(" ");
	    }
	    str.append(" |\n");

	    // draw horizontal walls
	    if (i < horWalls.length) {
		str.append("+");
		for (int j = 0; j < horWalls[i].length; j++) {
		    if (horWalls[i][j])
			str.append("-");
		    else
			str.append(" ");

		    str.append("+");
		}
		str.append("\n");
	    }

	}

	// draw bottom edge
	for (int j = 0; j < horWalls[0].length; j++) {
	    str.append("+-");
	}
	str.append("+\n");

	return str.toString();
    }

    // a class representing a cell in a maze
    class Cell {
	private Maze mz;
	private ArrayList<Cell> neighbors = new ArrayList<Cell>();
	private Cell parent = null;
	private int row;
	private int col;
	private boolean isGoal;

	public Cell (Maze mz, int row, int col, boolean isGoal) {
	    this.mz = mz;
	    this.row = row;
	    this.col = col;
	    this.isGoal = isGoal;
	}

	public void addNeighbor (Cell c) {
	    neighbors.add(c);
	}

	public ArrayList<Cell> getNeighbors () {
	    return neighbors;
	}

	public Cell getParent() { return parent; }
	public void setParent(Cell parent) { this.parent = parent; }

	public String toString() {
	    return "(" + row + ", " + col + ")";
	}

	public boolean isGoal () {
	    return isGoal;
	}
    }
			    
}

