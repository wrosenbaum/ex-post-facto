import java.util.Iterator;

public class StackList<T> implements SimpleStack<T>, Iterable<T> {
    Node top;    
    
    public void push(T item) {
	Node nd = new Node(item);
	nd.next = top;
	top = nd;
    }
    
    public T peek() {
	if (top == null) {
	    return null;
	}

	return top.item;
    }
    
    public T pop() {
	if (top == null) {
	    return null;
	}

	T item = top.item;
	top = top.next;
	return item;
    }
    
    public boolean isEmpty() {
	return (top == null);
    }

    public Iterator<T> iterator() {
	return new StackIterator();
    }


    class Node {
	T item;
	Node next;

	public Node (T item) {
	    this.item = item;
	    next = null;
	}
    }

    class StackIterator implements Iterator<T> {
	Node curr;
	
	public StackIterator() {
	    curr = top;
	}

	public boolean hasNext() {
	    return (curr != null);
	}

	public T next() {
	    if (curr == null) {
		return null;
	    }
	    
	    T item = curr.item;
	    curr = curr.next;
	    return item;
	}
    }
}
