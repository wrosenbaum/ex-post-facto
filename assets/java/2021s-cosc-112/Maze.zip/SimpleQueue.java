/**
 * An interface representing a simple first-in, first-out (FIFO) queue.
 */

public interface SimpleQueue<T> {
    /**
     * Enqueue item to the queue
     *
     * @param  item    the T item to be enqueued in the queue
     */
    void enq(T item);

    /**
     * Dequeue (i.e., remove and return) the first item in the queue. Returns null if the queue is currently empty
     *
     * @return        the first item in the queue, or null if the queue is empty
     */
    T deq();

    /**
     * Determine if the queue is currently empty
     *
     * @return        true if the queue is empty and false otherwise
     */
    boolean isEmpty();
}
