/*********************************************************************
 * Balance.java: A program that tests bracketed expressions for
 * balance. 
 ********************************************************************/

import java.util.Scanner;

public class Balance {

    public static final char[] BRACKETS = {'(', ')', '{', '}', '[', ']'};
    public static final char[] OPEN_BRACKETS = {'(', '{', '['};
    public static final char[] CLOSE_BRACKETS = {')', '}', ']'};

    // determine if ch is a bracket
    static boolean isBracket(char ch) {
	for (char bracket : BRACKETS) {
	    if (ch == bracket) {
		return true;
	    }
	}
	
	return false;	
    }

    // determine if is an opening bracket
    static boolean isOpen(char ch) {
	for (char bracket : OPEN_BRACKETS) {
	    if (ch == bracket) {
		return true;
	    }
	}

	return false;
    }

				      
    // determine if first and second are matching opening and closing
    // brackets
    static boolean arePair(char first, char second) {

	if (!isOpen(first)) {
	    return false;
	}
	
	int index;

	for (index = 0; index < OPEN_BRACKETS.length; ++index) {
	    if (first == OPEN_BRACKETS[index]) {
		break;
	    }
	}

	return (second == CLOSE_BRACKETS[index]);
    }


    // determine if an expression exp is balanced
    static boolean isBalanced (String exp) {
	char[] chexp = exp.toCharArray();
	SimpleStack<Character> brackets = new StackList<Character>();

	// scan expression f
	for (char ch : chexp) {

	    // ignore non-brackets
	    if (!isBracket(ch)) {
		continue;
	    }
	    
	    // push open brackets to the stack
	    if (isOpen(ch)) {
		brackets.push(ch);
	    } else {
		// if ch doesn't close the bracket on top of the
		// stack, the expression is not balanced; if it does
		// we should pop stack
		if (brackets.isEmpty() || !arePair(brackets.pop(), ch))
		    return false;
	    }
	}

	// if not all opening brackets have been closed, the
	// expression is not balanced
	if (!brackets.isEmpty())
	    return false;

	return true;
	
    }

    public static void main (String[] args) {

	Scanner scanner = new Scanner(System.in);

	while (true) {
	    System.out.print("Enter an expression (0 to exit): ");
	    String exp = scanner.nextLine();

	    if (exp.equals("0"))
		break;

	    if (isBalanced(exp))
		System.out.println("The expression is balanced!");
	    else
		System.out.println("The expression is not balanced!");
	}

	System.out.println("Goodbye!");

    }
}
