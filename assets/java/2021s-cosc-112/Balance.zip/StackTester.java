public class StackTester {
    static StackList<Integer> stk = new StackList<Integer>();
    
    static void  printStackContents() {
	System.out.println("stack contents: ");
	for (Integer i : stk) {
	    System.out.println(i);
	}
    }
    
    public static void main(String[] args) {


	System.out.println("stk is empty");

	// push some values to the stack
	System.out.println("pushing 1, 2, and 3...");
	
	stk.push(1);
	stk.push(2);
	stk.push(3);
	printStackContents();

	// print the top value
	System.out.println("the top value on the stack is " + stk.peek());

	// pop the top value    
	int val = stk.pop();
	System.out.println("popped " + val + " off the stack");
	printStackContents();

	// push another value
	val = 4;
	System.out.println("pushing " + val + " to the stack");
	stk.push(val);
	printStackContents();

	// remove everything from the stack
	System.out.println("removing everything from the stack...");
	
	while (!stk.isEmpty()) {
	    System.out.println("popped " + stk.pop());
	}
	
    }
}
