public interface SimpleStack<T> {
    // push a new item on the top of the stack
    public void push(T item);

    // return the item currently at the top of the stack
    public T peek();

    // remove and return the item currently at the top of the stack
    public T pop();

    // check if the stack is empty
    public boolean isEmpty();
}
