import java.util.Iterator;

public class StackList<T> implements SimpleStack<T>, Iterable<T> {
    Node top = null;    
    
    public void push(T item) {
	// create a Node storing item
	Node nd = new Node(item);

	// update next field of new Node to refer to top
	nd.next = top;

	// update top to refer to new node
	top = nd;
	
    }

    // return the top element stored in the stack, or
    // null if the stack is empty
    public T peek() {

	// check not empty
	// if (top == null) {
	//     return null;
	// }

	if (isEmpty()) {
	    return null;
	}

	return top.item;
    }
    
    public T pop() {

	// check not empty
	if (isEmpty()) {
	    return null;
	}

	// store current top item

	T item = top.item;

	// update top stack

	top = top.next;

	// return previous top item

	return item;
	
	
    }
    
    public boolean isEmpty() {
	if (top ==  null) {
	    return true;
	}

	return false;
	
    }

    class Node {
	public T item;
	public Node next;

	public Node (T item) {
	    this.item = item;
	    next = null;
	}
    }

    public Iterator<T> iterator() {
	return new StackIterator();
    }
    

    class StackIterator implements Iterator<T> {
	Node curr;
	
	public StackIterator() {
	    curr = top;
	}

	public boolean hasNext() {
	    return (curr != null);
	}

	public T next() {
	    if (curr == null) {
		return null;
	    }
	    
	    T item = curr.item;
	    curr = curr.next;
	    return item;
	}
    }
}
